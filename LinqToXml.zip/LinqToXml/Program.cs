﻿using System;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;

namespace LinqToXml
{
    class Program
    {
        static void Main()
        {
            #region Создание XMl-документа с элементами первого уровня line
            //Каждый элемент line содержит одну строку из файла и имеет атрибут num с номером строки
            var lines = File.ReadAllLines("../../XmlFiles/LinqXml1" +
                ".txt", Encoding.Default);
            XDocument doc = new XDocument(
              new XDeclaration(null, "windows-1251", null),
              new XElement("root",
                lines.Select( (line, index) => 
                  new XElement("line", line, new XAttribute("num", index + 1)) as XNode)));
            doc.Save("../../XmlFiles/LinqXml1.xml");

            #endregion Создание XMl-документа с элементами первого уровня line

            #region Поиск потомков для элементов первого уровня
            //Найти количество потомков, имеющих не менее двух атрибутов
            doc = XDocument.Load("../../XmlFiles/LinqXml2.xml");
                          
            var elements = doc.Root.Descendants()                //выбираем потомков
                        .Where(e => e.Attributes().Count() >= 2) //имеющих 2 и более атрибута
                        .OrderBy(e => e.Name.LocalName)          //располагаем их в алфавитном порядке
                        .ThenBy(e => e.Descendants().Count());   //при совпадении имён - в порядке возрастания количества потомков

            using (StreamWriter streamWriter = new StreamWriter("../../XmlFiles/LinqXml2.txt"))
            {
                foreach (var e in elements)
                {
                    streamWriter.WriteLine("Имя элемента: " + e.Name.LocalName + "   Количество потомков: " + e.Descendants().Count());
                }
            }

            #endregion Поиск потомков для элементов первого уровня

            #region Удаление дочерних узлов

            doc = XDocument.Load("../../XmlFiles/LinqXml3_Input.xml");

            foreach(var e in doc.Root.Elements().Elements())    // для каждого элемента второго уровня
                e.Nodes().Take(e.Nodes().Count() - 1).Remove(); // выбираем от начала на один узел меньше, чем их общее количество, и удаляем

            doc.Save("../../XmlFiles/LinqXml3_Output.xml");

            #endregion Удаление дочерних узлов

            #region Изменение имён элементов

            doc = XDocument.Load("../../XmlFiles/LinqXml4_Input.xml");

            foreach (var e in doc.Root.Descendants().Reverse()) // для всех потомков корневого элемента, начиная с последнего
                e.Name = e.Parent.Name.ToString() + "-" + e.Name.ToString(); // добавляем в начало имени имя родителя и -
            

            doc.Save("../../XmlFiles/LinqXml4_Output.xml");

            #endregion Изменение имён элементов

            #region Преобразование типов элементов

            doc = XDocument.Load("../../XmlFiles/LinqXml5_Input.xml");

            doc.Root.ReplaceNodes(doc.Root.Descendants() // заменяем тех потомков корневого элемента
                .Where(e => e.Elements().Count() == 0)   // у которых нет дочерних элементов (по условию они содержат дату)
                .Select(e => new XElement(e.Name, new XAttribute("year", ((DateTime)e).Year), new XAttribute("day", ((DateTime)e).Day))));
                // при этом добавляем к ним атрибуты year и day, значения котррых извлекаются путем преобразования типа из текста в datetime

            doc.Save("../../XmlFiles/LinqXml5_Output.xml");

            #endregion Преобразование типов элементов

            #region Обработка данных о клиентах фитнес-центра
            // Образец элемента первого уровня <record date="2000-05-01T00:00:00" id="10" time="PT5H13M"/>
            doc = XDocument.Load("../../XmlFiles/LinqXml6_Input.xml");

            XNamespace ns = doc.Root.Name.Namespace;

            var clientsInfo = doc.Root.Elements() // Выбираем все дочерние для корневого элементы
                .Select(e =>
                {
                    return new
                    {
                        id = (int)e.Attribute("id"), // и изменяем их, добавляя атрибуты id, время, год и месяц
                        time = e.Attribute("time"),
                        year = ((DateTime)e.Attribute("date")).Year,
                        month = ((DateTime)e.Attribute("date")).Month
                    };
                });

            doc.Root.ReplaceNodes(clientsInfo.OrderBy(e => e.id) // Заменяем исходные узлы документа, отсортировав их по возрастанию id,
                .GroupBy(e => e.id,                              // после чего группируем их по id клиента.
                (k, ee) => new XElement(ns + "client",
                new XAttribute("id", k), 
                ee.Select(v => new XElement(ns + "time", v.time, // Добавляем клиенту дочерний атрибут элемент time,
                new XAttribute("year", v.year),                  // содержащий атрибуты year и month и текстовое представление времени.
                new XAttribute("month", v.month)))
                .OrderBy(v => v.Attribute("year").Value)     // Сортируем дочерние элементы клиента (time) по возрастанию года,
                .ThenBy(v => v.Attribute("month").Value)))); // а при совпадении года - по возрастанию месяца


            doc.Save("../../XmlFiles/LinqXml6_Output.xml");

            #endregion Обработка данных о клиентах фитнес-центра

            #region Обработка данных об автозаправках
            // Образец элемента первого уровня:
            //<Лидер_ул.Чехова>
            //<brand>92</brand>
            //<price>2200</price>
            //</Лидер_ул.Чехова>
            doc = XDocument.Load("../../XmlFiles/LinqXml7_Input.xml");

            ns = doc.Root.Name.Namespace;
            // Аналогично предыдущему - выбираем все дочерние для корневого элементы
            var info = doc.Root.Elements()
                .Select(e =>
                {
                    string[] s = e.Name.LocalName.Split('_'); // Разбиваем имеющиеся названия элементов первого уровня
                    return new
                    {
                        company = s[0], // Записываем в атрибуты название компании, улицу, марку бензина и цену
                        street = s[1],
                        brand = int.Parse(e.Elements().First().Value),
                        price = int.Parse(e.Elements().Last().Value)
                    };
                });

            int[] brands = new int[] { 92, 95, 98 };

            doc.Root.ReplaceNodes(info.OrderBy(e => e.street)    // Заменяем дочерние узлы, но сначала
                .GroupBy(e => e.street,                          // сортируем и группируем их по названию улицы
                (k, ee) => new XElement(ns + k,                  // Элемент первого уровня теперь название фирмы
                brands.GroupJoin(ee, e1 => e1, e2 => e2.brand,   // Объединяем последовательности в элемент второго уровня - бренд
                (e1, ee2) => new XElement(ns + ("brand" + e1),   // Свойство-селектор для обоих объектов - название марки бензина
                ee2.Count() == 0 ? 0 : ee2.Average(e => e.price),// Элемент второго уровня - средняя цена
                new XAttribute("station-count", ee2.Count()      // Атрибут элемента - число продающих данную марку станций
                )))
                .OrderByDescending(v => v.Name.LocalName))));    // Сортировка по убыванию

            doc.Save("../../XmlFiles/LinqXml7_Output.xml");

            #endregion Обработка данных об автозаправках
        }
    }
}
