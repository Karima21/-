﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace LabControls
{
    public partial class RGBTextBox : TextBox
    {
        public bool Dec;

        public RGBTextBox()
        {
            InitializeComponent();
        }

        public RGBTextBox(IContainer container)
        {
            container.Add(this);
            InitializeComponent();
        }

        public void changeTextBox()
        {
            if (Dec)
            {
                Text = HexToDec(Text).ToString();
                
            }
            else
            {
                Text = Convert.ToString(int.Parse(Text), 16);
            }
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (Dec)
            {
                if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
                    e.Handled = true;
                base.OnKeyPress(e);
            }
            else
            {
                if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar) && !char.IsLetter(e.KeyChar))
                    e.Handled = true;
                base.OnKeyPress(e);
            }
        }

        private void RGBTextBox_TextChanged(object sender, EventArgs e)
        {
            int value;

            if (Dec)
            {
                if (int.TryParse(Text, out value))
                {
                    if (value > 255)
                    {
                        Text = "255";
                    }
                }
                else
                {
                    Text = "0";
                }
            }
            else
            {
                if (HexToDec(Text) > 255)
                {
                    Text = "ff";
                }
                else
                {
                    if (HexToDec(Text) <= 0)
                    {
                        Text = "0";
                    }
                }
                
            }           
        }

        public int HexToDec(string hex)
        {
            try
            {
                return Convert.ToInt32(hex, 16);
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
