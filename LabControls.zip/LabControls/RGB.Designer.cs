﻿namespace LabControls
{
    partial class RGB
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.labelRed = new System.Windows.Forms.Label();
			this.labelGreen = new System.Windows.Forms.Label();
			this.labelBlue = new System.Windows.Forms.Label();
			this.pictureBoxColor = new System.Windows.Forms.PictureBox();
			this.buttonDec = new System.Windows.Forms.RadioButton();
			this.radioButton1 = new System.Windows.Forms.RadioButton();
			this.buttonHex = new System.Windows.Forms.RadioButton();
			this.textBoxBlue = new LabControls.RGBTextBox(this.components);
			this.textBoxGreen = new LabControls.RGBTextBox(this.components);
			this.textBoxRed = new LabControls.RGBTextBox(this.components);
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxColor)).BeginInit();
			this.SuspendLayout();
			// 
			// labelRed
			// 
			this.labelRed.AutoSize = true;
			this.labelRed.Location = new System.Drawing.Point(13, 9);
			this.labelRed.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelRed.Name = "labelRed";
			this.labelRed.Size = new System.Drawing.Size(27, 13);
			this.labelRed.TabIndex = 0;
			this.labelRed.Text = "Red";
			// 
			// labelGreen
			// 
			this.labelGreen.AutoSize = true;
			this.labelGreen.Location = new System.Drawing.Point(4, 32);
			this.labelGreen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelGreen.Name = "labelGreen";
			this.labelGreen.Size = new System.Drawing.Size(36, 13);
			this.labelGreen.TabIndex = 1;
			this.labelGreen.Text = "Green";
			// 
			// labelBlue
			// 
			this.labelBlue.AutoSize = true;
			this.labelBlue.Location = new System.Drawing.Point(13, 54);
			this.labelBlue.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelBlue.Name = "labelBlue";
			this.labelBlue.Size = new System.Drawing.Size(28, 13);
			this.labelBlue.TabIndex = 2;
			this.labelBlue.Text = "Blue";
			// 
			// pictureBoxColor
			// 
			this.pictureBoxColor.Location = new System.Drawing.Point(122, -2);
			this.pictureBoxColor.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.pictureBoxColor.Name = "pictureBoxColor";
			this.pictureBoxColor.Size = new System.Drawing.Size(85, 93);
			this.pictureBoxColor.TabIndex = 6;
			this.pictureBoxColor.TabStop = false;
			// 
			// buttonDec
			// 
			this.buttonDec.AutoSize = true;
			this.buttonDec.Checked = true;
			this.buttonDec.Location = new System.Drawing.Point(28, 75);
			this.buttonDec.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.buttonDec.Name = "buttonDec";
			this.buttonDec.Size = new System.Drawing.Size(45, 17);
			this.buttonDec.TabIndex = 7;
			this.buttonDec.TabStop = true;
			this.buttonDec.Text = "Dec";
			this.buttonDec.UseVisualStyleBackColor = true;
			this.buttonDec.Click += new System.EventHandler(this.buttonDec_Click);
			// 
			// radioButton1
			// 
			this.radioButton1.AutoSize = true;
			this.radioButton1.Location = new System.Drawing.Point(-14, -15);
			this.radioButton1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.radioButton1.Name = "radioButton1";
			this.radioButton1.Size = new System.Drawing.Size(85, 17);
			this.radioButton1.TabIndex = 8;
			this.radioButton1.Text = "radioButton1";
			this.radioButton1.UseVisualStyleBackColor = true;
			// 
			// buttonHex
			// 
			this.buttonHex.AutoSize = true;
			this.buttonHex.Location = new System.Drawing.Point(78, 75);
			this.buttonHex.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.buttonHex.Name = "buttonHex";
			this.buttonHex.Size = new System.Drawing.Size(44, 17);
			this.buttonHex.TabIndex = 9;
			this.buttonHex.Text = "Hex";
			this.buttonHex.UseVisualStyleBackColor = true;
			this.buttonHex.Click += new System.EventHandler(this.buttonHex_Click);
			// 
			// textBoxBlue
			// 
			this.textBoxBlue.ForeColor = System.Drawing.SystemColors.WindowText;
			this.textBoxBlue.Location = new System.Drawing.Point(43, 52);
			this.textBoxBlue.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.textBoxBlue.Name = "textBoxBlue";
			this.textBoxBlue.Size = new System.Drawing.Size(76, 20);
			this.textBoxBlue.TabIndex = 5;
			this.textBoxBlue.Text = "0";
			this.textBoxBlue.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxBlue.TextChanged += new System.EventHandler(this.textBoxBlue_TextChanged);
			// 
			// textBoxGreen
			// 
			this.textBoxGreen.ForeColor = System.Drawing.SystemColors.WindowText;
			this.textBoxGreen.Location = new System.Drawing.Point(43, 29);
			this.textBoxGreen.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.textBoxGreen.Name = "textBoxGreen";
			this.textBoxGreen.Size = new System.Drawing.Size(76, 20);
			this.textBoxGreen.TabIndex = 4;
			this.textBoxGreen.Text = "0";
			this.textBoxGreen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxGreen.TextChanged += new System.EventHandler(this.textBoxGreen_TextChanged);
			// 
			// textBoxRed
			// 
			this.textBoxRed.ForeColor = System.Drawing.SystemColors.WindowText;
			this.textBoxRed.Location = new System.Drawing.Point(43, 6);
			this.textBoxRed.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.textBoxRed.Name = "textBoxRed";
			this.textBoxRed.Size = new System.Drawing.Size(76, 20);
			this.textBoxRed.TabIndex = 3;
			this.textBoxRed.Text = "0";
			this.textBoxRed.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.textBoxRed.TextChanged += new System.EventHandler(this.textBoxRed_TextChanged);
			// 
			// RGB
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoSize = true;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.Controls.Add(this.buttonHex);
			this.Controls.Add(this.radioButton1);
			this.Controls.Add(this.buttonDec);
			this.Controls.Add(this.pictureBoxColor);
			this.Controls.Add(this.textBoxBlue);
			this.Controls.Add(this.textBoxGreen);
			this.Controls.Add(this.textBoxRed);
			this.Controls.Add(this.labelBlue);
			this.Controls.Add(this.labelGreen);
			this.Controls.Add(this.labelRed);
			this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
			this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
			this.Name = "RGB";
			this.Size = new System.Drawing.Size(209, 94);
			((System.ComponentModel.ISupportInitialize)(this.pictureBoxColor)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelRed;
        private System.Windows.Forms.Label labelGreen;
        private System.Windows.Forms.Label labelBlue;
        private RGBTextBox textBoxRed;
        private RGBTextBox textBoxGreen;
        private RGBTextBox textBoxBlue;
        private System.Windows.Forms.PictureBox pictureBoxColor;
        private System.Windows.Forms.RadioButton buttonDec;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton buttonHex;
    }
}
