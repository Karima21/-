﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LabControls
{
    public partial class RGB : UserControl
    {
        private Bitmap bmp;
        private int r, g, b;

        public delegate void ColorHandler(object source, Color c);

        public event ColorHandler ColorChanged;

        public Color Color
        {
            get
            {              
                return Color.FromArgb(r, g, b);              
            }

            set
            {                
                Color = Color.FromArgb(r, g, b);
                
            }
        }

        public RGB()
        {
            InitializeComponent();
            bmp = new Bitmap(pictureBoxColor.Width, pictureBoxColor.Height);
            Graphics grf = Graphics.FromImage(bmp);
            grf.Clear(Color.Black);
            pictureBoxColor.Image = bmp;
            pictureBoxColor.Refresh();

            textBoxRed.Dec = true;
            textBoxGreen.Dec = true;
            textBoxBlue.Dec = true;
        }

        private void buttonHex_Click(object sender, EventArgs e)
        {
            textBoxRed.Dec = false;
            textBoxGreen.Dec = false;
            textBoxBlue.Dec = false;
            textBoxRed.changeTextBox();
            textBoxGreen.changeTextBox();
            textBoxBlue.changeTextBox();
        }

        private void buttonDec_Click(object sender, EventArgs e)
        {
            textBoxRed.Dec = true;
            textBoxGreen.Dec = true;
            textBoxBlue.Dec = true;
            textBoxRed.changeTextBox();
            textBoxGreen.changeTextBox();
            textBoxBlue.changeTextBox();
        }

        private void textBoxRed_TextChanged(object sender, EventArgs e)
        {           
            if (!textBoxRed.Dec)
            {
                r = textBoxRed.HexToDec(textBoxRed.Text);
            }
            else
            {
                r = int.Parse(textBoxRed.Text);
            }

            ColorChanged?.Invoke(this, Color);

            Graphics grf = Graphics.FromImage(bmp);
            grf.Clear(Color);
            pictureBoxColor.Image = bmp;
            pictureBoxColor.Refresh();
        }

        private void textBoxGreen_TextChanged(object sender, EventArgs e)
        {
            if (!textBoxGreen.Dec)
            {
                g = textBoxGreen.HexToDec(textBoxGreen.Text);
            }
            else
            {
                g = int.Parse(textBoxGreen.Text);
            }

            ColorChanged?.Invoke(this, Color);

            Graphics grf = Graphics.FromImage(bmp);
            grf.Clear(Color);
            pictureBoxColor.Image = bmp;
            pictureBoxColor.Refresh();
        }

        private void textBoxBlue_TextChanged(object sender, EventArgs e)
        {
            if (!textBoxBlue.Dec)
            {
                b = textBoxBlue.HexToDec(textBoxBlue.Text);
            }
            else
            {
                b = int.Parse(textBoxBlue.Text);    
            }

            ColorChanged?.Invoke(this, Color);

            Graphics grf = Graphics.FromImage(bmp);
            grf.Clear(Color);
            pictureBoxColor.Image = bmp;
            pictureBoxColor.Refresh();
        }    
    }
}
