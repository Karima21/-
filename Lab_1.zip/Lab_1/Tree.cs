﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    public class Tree
    {
        public TreeNode Data { get; set; }

        public TreeNode FillTheTree(List<Ident> entries) // функция заполнения дерева
        {
            TreeNode root = null;

            foreach (Ident entry in entries)
            {
                TreeNode newNode = new TreeNode(entry);

                root = Insert(root, newNode);
            }

            return root;
        }

        public TreeNode Insert(TreeNode root, TreeNode newNode) // добавления верщины в бинарное дерево 
                                                                // в зависимости от значения хеш-кода (меньше - налево, больше - направо)
        {
            if (root == null)
            {
                root = newNode;
            }

            else if (newNode.Value.HashCode < root.Value.HashCode)
            {
                root.Left = Insert(root.Left, newNode);
            }

            else
            {
                root.Right = Insert(root.Right, newNode);
            }

            return root;
        }       
    }
    public class TreeNode
    {
        public Ident Value { get; set; }
        public TreeNode Left { get; set; }
        public TreeNode Right { get; set; }
        public TreeNode(Ident value)
        {
            Value = value;
        }
    }
}
