﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab1
{
    public class FileParser
    {
        // Чтение файла при помощи StreamReader
        public List<Ident> ParseFile(StreamReader streamReader)
        {
            List<Ident> entries = new List<Ident>();

            // Пока не конец потока
            while (!streamReader.EndOfStream)
            {
                string currentString = streamReader.ReadLine(); // Читаем текущую строку
                if (!string.IsNullOrWhiteSpace(currentString))  // Если строка непустая
                {
                    CheckCurrentString(currentString, ref entries); // проверяем текущую строку и заполняем список идентификаторов
                }
            }
            return entries;
        }

        static bool IsMethod(string str) // Проверка формы строки, содержащей метод
        {
            Regex methodRegex = new Regex(@"\s*(int|char|float|bool|string){1}\s+\w+\({1}.*\){1}");
            return methodRegex.IsMatch(str);

        }

        static bool IsVar(string str) // Проверка формы строки, содержащей переменную
        {
            Regex varRegex = new Regex(@".*\W*[(int)(char)(float)(bool)(string)]\s[a-z].*\W*\;");
            return varRegex.IsMatch(str);
        }

        static void CheckCurrentString(string currentString, ref List<Ident> entries) // Проверка строки и создание объекта 
        {
            // Объект, который содержит методы проверки
            Verify vrf = new Verify();

            // Создание объекта в зависимости от формата строки
            switch (currentString)
            {
                case string a when a.Contains("class "):
                    CreateClass(currentString, ref entries, vrf);
                    break;
                case string b when b.Contains("const "):
                    CreateConst(currentString, ref entries, vrf);
                    break;
                case string c when IsMethod(c):
                    CreateMethod(currentString, ref entries, vrf);
                    break;
                case string d when IsVar(d):
                    CreateVar(currentString, ref entries, vrf);
                    break;
                default: throw new Exception("Invalid string format");
            }
        }

        static void CreateClass(string str, ref List<Ident> entries, Verify vrf)
        {
            // Добавление класса в список индентификаторов
            entries.Add(new Ident(str.Replace("class ", "").Replace(";", ""), VarTypes.class_type, ClassTypes.CLASSES));
        }
        static void CreateConst(string str, ref List<Ident> entries, Verify vrf)
        {
            // Добавление константы
            Regex constRegex = new Regex(@"\s*(const)\s+(?<constType>(string|int|char|float|bool))\s+(?<constName>\w+\d*)\s+\=\s+(?<constValue>\W*([\w+\s*]+|[\d+\W*]+)\W*)\;");
            Match constMatch = constRegex.Match(str);

            if (constMatch.Success) // Если строка соответствует формату
            {
                string constType = constMatch.Groups["constType"].Value;   // Достаём из строки тип константы
                string constName = constMatch.Groups["constName"].Value;   // Достаём имя константы
                string constValue = constMatch.Groups["constValue"].Value; // Достаём значение константы

                entries.Add(new Constant(constName, vrf.VerifyVarType(constType), ClassTypes.CONSTS,
                    vrf.CreateObject(vrf.VerifyVarType(constType), constValue))); // добавляем константу в список индентификаторов
            }
            else
            {
                throw new Exception("Regex does not match");
            }
        }
        static void CreateVar(string str, ref List<Ident> entries, Verify vrf)
        {
            // добавляем переменную
            Regex varRegex = new Regex(@"\s*(?<varType>(string|int|char|float|bool))\s+(?<varName>\w+\d*)\s*;");
            Match varMatch = varRegex.Match(str);

            if (varMatch.Success)
            {
                string varType = varMatch.Groups["varType"].Value; // Достаём из строки тип переменной
                string varName = varMatch.Groups["varName"].Value; // и её значение

                VarTypes type = vrf.VerifyVarType(varType); // Определяем тип переменной

                entries.Add(new Ident(varName, type, ClassTypes.VARS)); // Добаляем переменную в список
            }
            else
            {
                throw new Exception("Regex does not match");
            }
        }
        static void CreateMethod(string str, ref List<Ident> entries, Verify vrf)
        {
            // Добавляем метод
            Regex methodRegex = new Regex(@"\s*(?<methodType>(int|char|float|bool|void|string))\s+(?<methodName>[\w+\d*]+)\s*\((?<methodArguments>.*)\)\s*");
            Match methodMatch = methodRegex.Match(str);

            if (methodMatch.Success)
            {
                string methodType = methodMatch.Groups["methodType"].Value;
                string methodName = methodMatch.Groups["methodName"].Value;
                string methodArguments = methodMatch.Groups["methodArguments"].Value; // Информация о параметрах в строке

                LinkedList<ListMethods> listWithParams = new LinkedList<ListMethods>();
                GetArgumets(methodArguments, ref listWithParams);

                entries.Add(new Method(methodName, vrf.VerifyVarType(methodType), ClassTypes.METHODS, listWithParams));
            }
            else
            {
                throw new Exception("Regex does not match");
            }
        }
        static void GetArgumets(string arguments, ref LinkedList<ListMethods> filledList) // Метод записи информации об параметрах из строки в список
        {
            char[] splitter = { ',' };
            string[] parametersByOne = arguments.Split(splitter, StringSplitOptions.RemoveEmptyEntries);

            Verify vrf = new Verify();

            for (int i = 0; i < parametersByOne.Length; i++)
            {
                Regex paramRegex = new Regex(@"\s*((?<varTupy>(ref|out))\s+)*(?<parameterType>(string|int|char|float|bool)).*");
                Match parameterMatch = paramRegex.Match(parametersByOne[i]);

                if (parameterMatch.Success)
                {
                    string transferType = parameterMatch.Groups["varType"].Value; // тип передачи
                    string parameterType = parameterMatch.Groups["parameterType"].Value; // значение

                    filledList.Add(new ListMethods(vrf.VerifyVarType(parameterType), vrf.VerifyParamType(transferType))); 
                    // добавляем параментр в лист
                }
                else
                {
                    throw new Exception("Invalid string format");
                }
            }
        }
    }
}
