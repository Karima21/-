﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab1
{
    public class ListMethods // объект, который описывает инфомацию о параментрах
    {
        public VarTypes Var_Type { get; set; }
        public ParamTypes Param_Type { get; set; }

        public ListMethods(VarTypes v, ParamTypes p)
        {
            Var_Type = v;
            Param_Type = p;
        }
    }

    class Method : Ident
    {  
        public LinkedList<ListMethods> ParamInfo { get; set; }
        public Method(string n, VarTypes v, ClassTypes c, LinkedList<ListMethods> p) : base(n, v, c)
        {
          ParamInfo = p;
        }
    }
}
