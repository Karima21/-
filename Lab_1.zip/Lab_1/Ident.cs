﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    public enum ClassTypes // способ использования идентификатора
    {
        CLASSES,
        CONSTS,
        VARS,
        METHODS,
    }

    public enum ParamTypes // способ передачи параметра
    {
        param_val,
        param_ref,
        param_out
    }

    public enum VarTypes // тип идентификатора
    {
        int_type,
        float_type,
        bool_type,
        char_type,
        string_type,
        class_type
    }
    public class Ident
    {
        public string Name { get; set; }
        public int HashCode
        {
            get { return Name.GetHashCode(); }
        }

        public ClassTypes Class_Type { get; set; }

        public VarTypes Var_Type { get; set; }

        public Ident(string n, VarTypes v, ClassTypes c)
        {
            Name = n;
            Var_Type= v;
            Class_Type = c;
        }

        public override string ToString()
        {
            return $"{Name} {HashCode} {Class_Type} {Var_Type}";
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode();
        }
    }
}
