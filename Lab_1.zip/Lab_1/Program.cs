﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Lab1
{
    public class Program
    {
        public static string GetHash(string password, string salt)
        {
            //Экземпляр объекта MD5
            MD5 md5 = new MD5CryptoServiceProvider();
            //Вычисление хэш-значения
            byte[] digest = md5.ComputeHash(Encoding.UTF8.GetBytes(password + salt));
            //Получение строкового значения из массива байт
            string base64digest = Convert.ToBase64String(digest, 0, digest.Length);
            return base64digest;
        }
        static void Main(string[] args)
        {
            Console.WriteLine(GetHash("1", "Sveta"));
            Console.WriteLine(GetHash("2", "Sveta"));
            Console.WriteLine(GetHash("3", "Sveta"));
            Console.WriteLine(GetHash("4", "Sveta"));
            Console.ReadLine();
            return;

            using (StreamReader streamReader = new StreamReader("../../input.txt"))
            {
                FileParser parser = new FileParser();

                // читаем данные из файла
                List<Ident> entries = parser.ParseFile(streamReader);

                // заполняем дерево
                Tree tree = new Tree();
                TreeNode root = tree.FillTheTree(entries);
            }
        }
    }
}
