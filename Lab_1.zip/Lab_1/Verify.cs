﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    public class Verify
    {
        public ParamTypes VerifyParamType(string transType)
        {
            ParamTypes definedTransferType = ParamTypes.param_val;
            switch (transType)
            {
                case "":
                    definedTransferType = ParamTypes.param_val;
                    break;
                case "ref":
                    definedTransferType = ParamTypes.param_ref;
                    break;
                case "out":
                    definedTransferType = ParamTypes.param_out;
                    break;
            }

            return definedTransferType;
        }
        public VarTypes VerifyVarType(string type)
        {
            VarTypes definedType = VarTypes.int_type;
            switch (type)
            {
                case "string":
                    definedType = VarTypes.string_type;
                    break;

                case "char":
                    definedType = VarTypes.char_type;
                    break;

                case "float":
                    definedType = VarTypes.float_type;
                    break;

                case "bool":
                    definedType = VarTypes.bool_type;
                    break;
                case "class":
                    definedType = VarTypes.bool_type;
                    break;
            }

            return definedType;
        }

        public object CreateObject(VarTypes type, string value)
        {
            object objectValue = new object();

            switch (type)
            {
                case VarTypes.string_type:

                    if (value.Contains(@""""))
                    {
                        string rplc = value.Replace(@"""", "");
                        objectValue = rplc;
                    }
                    else
                    {
                        throw new Exception("Type does not match value");
                    }

                    break;

                case VarTypes.bool_type:

                    bool b;
                    if (bool.TryParse(value, out b))
                    {
                        objectValue = b;
                    }
                    else
                    {
                        throw new Exception("Type does not match value");
                    }

                    break;

                case VarTypes.int_type:

                    int i;
                    if (int.TryParse(value, out i))
                    {
                        objectValue = i;
                    }
                    else
                    {
                        throw new Exception("Type does not match value");
                    }

                    break;

                case VarTypes.float_type:

                    float f;
                    if (float.TryParse(value, out f))
                    {
                        objectValue = f;
                    }
                    else
                    {
                        throw new Exception("Type does not match value");
                    }

                    break;

                case VarTypes.char_type:

                    char c;
                    if (value.Contains(@"'"))
                    {
                        string rplc = value.Replace("'", "");
                        if (char.TryParse(rplc, out c))
                        {
                            objectValue = c;
                        }
                        else
                        {
                            throw new Exception("Type does not match value");
                        }
                    }
                    else
                    {
                        throw new Exception("Type does not match value");
                    }
                    break;
            }
            return objectValue;         
        }
    }
}

