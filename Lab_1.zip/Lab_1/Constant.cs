﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lab1
{
    class Constant : Ident
    {      
        protected object Const; // Значение константы
        public Constant(string n, VarTypes v, ClassTypes c, object o) : base(n, v, c)
        {
            Const = o;
        }
    }
}
