﻿using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Xsl;
using static System.Console;


namespace Timetable
{
    class Program
    {
        static void Main()
        {
            ReadLine();

            XDocument doc; doc = XDocument.Load("../../tbl.xml");

            #region XPath запросы

            var allClasses = doc.Root.XPathSelectElements("//subject")
                .Select(e => e.Attribute("name").Value).Distinct();

            var allRooms = doc.Root.XPathSelectElements("//subject/room")
                .Select(e => e.Value).Distinct();

            var allSeminars = doc.Root.XPathSelectElements("//subject[types = 'seminar']")
                .Select(e => e.Attribute("name").Value).Distinct();

            var allLecturesInARoom = doc.Root.XPathSelectElements("//subject[types = 'lecture' and room = '102']")
                .Select(e => e.Attribute("name").Value).Distinct();

            var allSeminaristsInARoom = doc.Root.XPathSelectElements("//subject[types = 'seminar' and room = '102']/teacher")
                .Select(e => e.Value).Distinct();

            var lastClassesinADay = doc.Root.XPathSelectElements("//subject[last()]")
                .Select(e => e.Attribute("name").Value);

            double numberOfClasses = (double)doc.Root.XPathEvaluate("count(//subject)");

            using (StreamWriter streamWriter = new StreamWriter("../../output.txt"))
            {
                streamWriter.WriteLine("Список занятий:");
                foreach (string s in allClasses)
                {
                    streamWriter.WriteLine(s);
                }
                
                streamWriter.WriteLine("\nСписок аудиторий, в которых проходят занятия:");
                foreach (string s in allRooms)
                {
                    streamWriter.WriteLine(s);
                }

                streamWriter.WriteLine("\nСписок семинаров:");
                foreach (string s in allSeminars)
                {
                    streamWriter.WriteLine(s);
                }

                streamWriter.WriteLine("\nСписок лекций в 102-ой аудитории:");
                foreach (string s in allLecturesInARoom)
                {
                    streamWriter.WriteLine(s);
                }

                streamWriter.WriteLine("\nСписок преподавателей, проводящих семинары в 102 аудитории:");
                foreach (string s in allSeminaristsInARoom)
                {
                    streamWriter.WriteLine(s);
                }

                streamWriter.WriteLine("\nСписок последних занятий каждого дня на этой неделе:");
                foreach (string s in lastClassesinADay)
                {
                    streamWriter.WriteLine(s);
                }

                streamWriter.WriteLine("\nКоличество занятий на этой неделе: " + numberOfClasses);
            }

            #endregion XPath запросы

            #region DTD validating 

            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Parse,
                //ValidationType = ValidationType.DTD
            };

            settings.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);

            XmlReader reader = XmlReader.Create("../../tbl.xml", settings);

            while (reader.Read()) { }

            #endregion DTD validating

            #region XSD validating

            settings.Schemas.Add(null,"../../tbl.xsd");
            settings.ValidationType = ValidationType.Schema;
            settings.DtdProcessing = DtdProcessing.Ignore;
            settings.ValidationEventHandler -= new ValidationEventHandler(ValidationCallBack);
            settings.ValidationEventHandler += new ValidationEventHandler(SettingsValidationEventHandler);

            reader = XmlReader.Create("../../tbl.xml", settings);

            while (reader.Read()) { }

            #endregion XSD validating

            #region XSLT преобразование в TXT

            XPathDocument XPathDoc = new XPathDocument("../../tbl.xml");
            XslCompiledTransform tranform = new XslCompiledTransform();
            tranform.Load("../../ToTXT.xsl");
            XmlTextWriter writer = new XmlTextWriter("../../tbl.txt", null);
            tranform.Transform(XPathDoc, null, writer);

            #endregion XSLT преобразование в TXT

            #region XSLT преобразование в HTML

            XPathDoc = new XPathDocument("../../tbl.xml");
            tranform = new XslCompiledTransform();
            tranform.Load("../../ToHTML.xsl");
            writer = new XmlTextWriter("../../tbl.html", null);
            tranform.Transform(XPathDoc, null, writer);

            #endregion XSLT преобразование в HTML
        }

        private static void ValidationCallBack(object sender,
                            ValidationEventArgs e)
        {
            WriteLine("Документ xml не валиден: {0}",
                                    e.Message);
        }

        private static void SettingsValidationEventHandler(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Warning)
            {
                Write("WARNING: ");
                WriteLine(e.Message);
            }
            else if (e.Severity == XmlSeverityType.Error)
            {
                Write("ERROR: ");
                WriteLine(e.Message);
            }
        }
    }
}